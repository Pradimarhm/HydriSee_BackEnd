import cv2, joblib, numpy as np, os, shutil
from skimage.feature import local_binary_pattern
from pillow_heif import read_heif

import warnings
warnings.filterwarnings("ignore", category=UserWarning)

# ============= PATH =============
FOLDER_ESP = r"D:\ME\KULIAH\SEMESTER 5\PROJEK\smt5\esp_image"

FOLDER_DONE = r"D:\ME\KULIAH\SEMESTER 5\PROJEK\smt5\esp_done"
FOLDER_DONE_TRUE  = os.path.join(FOLDER_DONE, "terdeteksibelalang")
FOLDER_DONE_FALSE = os.path.join(FOLDER_DONE, "tidakadabelalang")

for p in [FOLDER_ESP, FOLDER_DONE, FOLDER_DONE_TRUE, FOLDER_DONE_FALSE]:
    os.makedirs(p, exist_ok=True)

# ============= LOAD MODEL =============
MODEL_PATH = r"D:\ME\KULIAH\SEMESTER 5\PROJEK\smt5\python\naivebayes_pakcoy.pkl"
model = joblib.load(MODEL_PATH)

# ============= BACA Gambar =============
def read_image_any_format(path):
    ext = os.path.splitext(path)[1].lower()
    if ext == ".heic":
        heif = read_heif(path)
        img = np.array(heif)
        return cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
    else:
        return cv2.imread(path)

# ============= EKSTRAKSI FITUR =============
def extract_features(img):
    img = cv2.resize(img, (128,128))
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    feats = [
        np.mean(hsv[:,:,0])/179,
        np.mean(hsv[:,:,1])/255,
        np.mean(hsv[:,:,2])/255,
        np.std(hsv[:,:,0])/179,
        np.std(hsv[:,:,1])/255,
        np.std(hsv[:,:,2])/255,
    ]

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    feats.append(np.mean(gray)/255)
    feats.append(np.std(gray)/255)

    edges = cv2.Canny(gray,100,200)
    feats.append(np.sum(edges>0)/edges.size)

    lbp = local_binary_pattern(gray, P=8, R=1, method='uniform')
    lbp_hist,_ = np.histogram(lbp.ravel(), bins=np.arange(0,10), density=True)
    feats.extend(lbp_hist)

    return np.array(feats).reshape(1,-1)

# ============= PATCH GRID =============
def generate_patches(img, gs=4):
    patches = []
    h, w = img.shape[:2]
    ph, pw = h // gs, w // gs
    for i in range(gs):
        for j in range(gs):
            p = img[i*ph:(i+1)*ph, j*pw:(j+1)*pw]
            if p.size > 0:
                patches.append(p)
    return patches

# ============= ORB DETECTOR =============
orb = cv2.ORB_create(nfeatures=500)

def orb_keypoints(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    kp = orb.detect(gray, None)
    return len(kp)

# ============= AMBIL GAMBAR TERTUA =============
def get_oldest(path):
    fs = [os.path.join(path, f)
          for f in os.listdir(path)
          if f.lower().endswith((".jpg",".jpeg",".png",".heic"))]
    if not fs: return None
    fs.sort(key=os.path.getmtime)
    return fs[0]

# ============= LOOP =============
while True:
    img_path = get_oldest(FOLDER_ESP)
    if img_path is None:
        print("⚠ Tidak ada gambar.")
        break

    print(f"\n🔍 Memproses: {os.path.basename(img_path)}")
    img = read_image_any_format(img_path)
    if img is None:
        continue

    patches = generate_patches(img, 4)

    vote_nb = 0
    vote_orb = 0

    global_orb = orb_keypoints(img)

    # Jika gambar super putih → pasti pakcoy
    hsv_global = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    if np.mean(hsv_global[:,:,2]) > 230:  # terlalu terang
        final = "tidakadabelalang"
    else:
        # PATCH CHECK
        for p in patches:
            feats = extract_features(p)
            pred = model.predict(feats)[0]
            if pred == "belalang":
                vote_nb += 1

            kp = orb_keypoints(p)
            if kp > 35:  # keypoint threshold
                vote_orb += 1

        # === FINAL DECISION ===
        if vote_nb >= 3:
            final = "belalang"
        elif vote_orb >= 4:
            final = "belalang"
        elif global_orb > 150:
            final = "belalang"
        else:
            final = "tidakadabelalang"

    print(f"📌 Vote NB = {vote_nb}, Vote ORB = {vote_orb}, ORB global = {global_orb}")
    print(f"📌 HASIL: {final}")

    # tampilkan
    show = cv2.resize(img, (500, 500))
    cv2.putText(show, f"Prediksi: {final}", (10,40),
                cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,0), 2)
    cv2.imshow("ESP Prediksi", show)
    cv2.waitKey(700)

    # pindah file
    dest = FOLDER_DONE_TRUE if final == "belalang" else FOLDER_DONE_FALSE
    shutil.move(img_path, os.path.join(dest, os.path.basename(img_path)))

cv2.destroyAllWindows()
print("\n=== SELESAI ===")
